package com.cg.tms.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Random;

import com.cg.tms.dao.TicketDAOImpl;
import com.cg.tms.dto.TicketBean;
import com.cg.tms.dto.TicketCategory;

public class TicketServiceImpl {
	private TicketDAOImpl Dao = new TicketDAOImpl();
	public TicketDAOImpl getDao() {
		return Dao;
	}

	
	public List<TicketCategory> ListTicketCategory() {
		
		return getDao().ListTicketCategory();
	}
//	 Map<String,String> getTicketCategory(){
//		return getDao().getTicketCategoryEntries();
//	}
	public int raiseNewTicket(TicketBean ticketBean) {
		int ticketNo = generateTicketNo();
		ticketBean.setTicketNo(ticketNo);
		return getDao().raiseNewTicket(ticketBean);
	}
	private int generateTicketNo()
	{
		int ticketNo = new Random().nextInt(10000);
		return ticketNo;
	}
}
