package com.cg.tms.service;

import java.util.Map;

public interface TicketService {
	 Map<String,String> getTicketCategory();
}
