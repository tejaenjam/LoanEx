package com.cg.tms.dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.cg.tms.dto.TicketBean;
import com.cg.tms.dto.TicketCategory;


public class TicketDAOImpl {
private static Map<String,TicketCategory> ticketCategory=new HashMap<String,TicketCategory>();
private static Map<Integer, TicketBean> tickets = new HashMap<Integer, TicketBean>();
private static Map<String,TicketCategory> getTicketCategoryEntries(){
	ticketCategory.put("tc001", new TicketCategory("tc001", "software installation"));
	ticketCategory.put("tc002", new TicketCategory("tc002", "mailbox creation"));
	ticketCategory.put("tc003", new TicketCategory("tc003", "mailbox issues"));


return ticketCategory;

}



public List<TicketCategory> ListTicketCategory() {

	
	
	
	List<TicketCategory> myList = new ArrayList(getTicketCategoryEntries().values());
	


	
	return myList;
	

}



public int raiseNewTicket(TicketBean ticketBean) {
	// TODO Auto-generated method stub
	tickets.put(ticketBean.getTicketNo(), ticketBean);
	return ticketBean.getTicketNo();
}


}
