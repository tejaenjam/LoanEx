package com.cg.tms.dao;


import static org.junit.Assert.assertEquals;

import org.junit.Test;

import com.cg.tms.dto.TicketBean;
import com.cg.tms.dto.TicketCategory;


public class DaoTest {
	TicketDAOImpl dao=new TicketDAOImpl();
	TicketCategory bean1=new TicketCategory("tc001", "software installation");
	TicketBean bean = new TicketBean(4577, "jgdc", "low", "new",bean1);
	@Test
	 public void A()
	{
		 long a= dao.raiseNewTicket(bean);
		 System.out.println(a);
		 assertEquals(4577, a);
	}
	 
}
