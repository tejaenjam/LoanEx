package com.cg.tms.ui;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Calendar;
import java.util.List;
import java.util.ListIterator;
import java.util.Scanner;

import com.cg.tms.dto.TicketBean;
import com.cg.tms.dto.TicketCategory;
import com.cg.tms.exception.TicketSystemException;
import com.cg.tms.service.TicketServiceImpl;

public class MainUI {
	
	
	private static Scanner sc = new Scanner(System.in);
	private static TicketServiceImpl Service = new TicketServiceImpl();

	public static void showMenu() { // Prints the menu
		System.out.println(
				"*********************Welcome to itmd helpdesk*****************\n1. Raise a ticket\n2. Exit from system\n\n******************************************************\nPlease enter a choice:\n");
	}
	static TicketServiceImpl getService() {
		return Service;
	}
	public static void run() throws TicketSystemException
	{
		char run='y';
		int i=0;
		do
		{
			showMenu();
			String choice = sc.next().trim(); // getting user choice for menu
			switch (choice) {
			case "1":// Register Flat
				System.out.println("Select Ticket category from below list ");
//				System.out.println(getService().ListTicketCategory());
				List a=getService().ListTicketCategory();
				ListIterator<TicketCategory> 
                iterator = a.listIterator(); 
            while (iterator.hasNext()) { 
                System.out.println(++i +"."
                                   + iterator.next().getCategoryName()); 
            } 
            System.out.println("Enter option");
				int ticketnum=0;
				try
				{
				ticketnum=sc.nextInt();
				}
				catch (NumberFormatException e) {
					throw new TicketSystemException("Please enter valid ticket category from the list. ");
				}
				
				TicketCategory ticketCat = null;
				switch(ticketnum)
				{
				case 1:
					
					ticketCat = getService().ListTicketCategory().get(0);
					System.out.println(ticketCat);
					break;
				case 2:
					ticketCat = getService().ListTicketCategory().get(1);
					break;
				case 3:
					ticketCat = getService().ListTicketCategory().get(2);
					break;
				default:
					System.out.println("Please enter valid ticket category from the list. ");
					run = sc.next().charAt(0);
					break;
				}
			
				System.out.println("Enter description related issue");
				String ticketDescription=sc.next();
				sc.hasNextLine();
				System.out.println("Enter Priority");
				int priorityNum=0;
				String priority ="";
				priorityNum=sc.nextInt();
				switch(priorityNum)
				{
				case 1:
					priority = "low";
					break;
				case 2:
					priority = "medium";
					break;
				case 3:
					priority = "high";
					break;
				default:
					System.out.println("Please enter valid priority");
					System.out.println("\nDo you want to continue? (y/n)......");
					run = sc.next().charAt(0);
					break;
				
				}
				while(run=='y')
				{
				
				
				TicketBean ticket = new TicketBean(0, ticketDescription, priority, "new",ticketCat);
				int ticketNo =  getService().raiseNewTicket(ticket);

				if (ticketNo != 0) {
					DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");  
					   LocalDateTime now = LocalDateTime.now();  
					
					
					System.out.println("Ticket Number "+ ticketNo+ " logged successfully at " + dtf.format(now));
					break;
				}
				}
				
				
				
				break;
			case "2":
				System.out.println("Exit");
				System.out.println("Thankyou for using");
				System.exit(0);
				break;
			default:
				System.out.println("\nDo you want to continue? (y/n)......");
				run = sc.next().charAt(0);
				break;
			
		}
		}
			while (run == 'y' || run == 'Y');
			sc.close();
		
	}
	
	
public static void main(String[] args) throws TicketSystemException {
	Scanner sc=new Scanner(System.in);

	run();
}
}
