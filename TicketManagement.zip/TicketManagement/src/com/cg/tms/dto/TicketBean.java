package com.cg.tms.dto;

public class TicketBean {
private String ticketNo;
private String ticketDescription;
private String ticketPriority;
private String ticketStatus;
private String ticketCategory;
public TicketBean(String ticketCategory, String ticketDescription, String ticketPriority) {
	// TODO Auto-generated constructor stub
	
	this.ticketDescription=ticketDescription;
	this.ticketCategory=ticketCategory;
	this.ticketPriority=ticketPriority;
	
	
}
public String getTicketNo() {
	return ticketNo;
}
public void setTicketNo(String ticketNo) {
	this.ticketNo = ticketNo;
}
public String getTicketDescription() {
	return ticketDescription;
}
public void setTicketDescription(String ticketDescription) {
	this.ticketDescription = ticketDescription;
}
public String getTicketPriority() {
	return ticketPriority;
}
public void setTicketPriority(String ticketPriority) {
	this.ticketPriority = ticketPriority;
}
public String getTicketStatus() {
	return ticketStatus;
}
public void setTicketStatus(String ticketStatus) {
	this.ticketStatus = ticketStatus;
}
public String getTicketCategory() {
	return ticketCategory;
}
public void setTicketCategory(String ticketCategory) {
	this.ticketCategory = ticketCategory;
}
@Override
	public String toString() {
		// TODO Auto-generated method stub
		return ticketNo+ " "+ticketCategory+ " "+ticketDescription+ " " +ticketPriority+ " " + ticketStatus;
	}
}
