package com.cg.tms.dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import com.cg.tms.dto.TicketBean;


public class TicketDAOImpl {
private static Map<String,String> ticketCategory=new HashMap<String,String>();
private static Map<String,TicketBean> ticketlog=new HashMap<String,TicketBean>();
static 
{
ticketCategory.put("tc001","Software installation");
ticketCategory.put("tc002","Mailbox creation");
ticketCategory.put("tc003","Mailbox issues");

}
public int raiseNewTicket(TicketBean ticketBean)
{
	
		int id = 1;
		for (int i = 0; i < 4; i++) {
			id = (int) (id * 10 + Math.random() * 10);
		}
			String id1=Integer.toString(id);
		
	ticketlog.put( id1,ticketBean);
		
	return id;
	
}


public ArrayList<String> ListTicketCategory() {
	System.out.println("Dao entered");
	ArrayList<String> ticketlist = new ArrayList<>(ticketCategory.keySet());
	
	return ticketlist;
}

}
