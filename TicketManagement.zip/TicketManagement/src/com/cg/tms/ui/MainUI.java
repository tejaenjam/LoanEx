package com.cg.tms.ui;

import java.util.Scanner;

import com.cg.tms.dto.TicketBean;
import com.cg.tms.service.TicketServiceImpl;

public class MainUI {
	
	
	private static Scanner sc = new Scanner(System.in);
	private static TicketServiceImpl Service = new TicketServiceImpl();

	public static void showMenu() { // Prints the menu
		System.out.println(
				"*********************Welcome to itmd helpdesk*****************\n1. Raise a ticket\n2. Exit from system\n\n******************************************************\nPlease enter a choice:\n");
	}
	static TicketServiceImpl getService() {
		return Service;
	}
	public static void run()
	{
		char run='y';
		do
		{
			showMenu();
			String choice = sc.next().trim(); // getting user choice for menu
			switch (choice) {
			case "1":// Register Flat
				System.out.println("Select Ticket category from below list ");
				System.out.println(getService().ListTicketCategory());
				String ticketCategory=sc.next();
				System.out.println("Enter description related issue");
				String ticketDescription=sc.next();
				sc.hasNextLine();
				System.out.println("Enter Priority");
				String ticketPriority=sc.next();
			//	((TicketServiceImpl) getService()).validateDetails(ownerId, flatType, deposit, rent, area);
				TicketBean ticketBean = new TicketBean(ticketCategory,ticketDescription,ticketPriority);
				int ticket = getService().raiseNewTicket(ticketBean);
				System.out.println("Ticket number " +ticket+ "logged successfully");
				break;
			case "2":
				System.out.println("Exit");
				break;
			default:
				System.out.println("Please select a valid option!");
				break;
		}
		}
			while (run == 'y' || run == 'Y');
			sc.close();
		
	}

public static void main(String[] args) {
	Scanner sc=new Scanner(System.in);

	run();
}
}
