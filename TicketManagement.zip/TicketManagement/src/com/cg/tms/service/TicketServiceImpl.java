package com.cg.tms.service;

import java.util.ArrayList;
import java.util.List;

import com.cg.tms.dao.TicketDAOImpl;
import com.cg.tms.dto.TicketBean;
import com.cg.tms.dto.TicketCategory;

public class TicketServiceImpl {
	private TicketDAOImpl Dao = new TicketDAOImpl();
	public TicketDAOImpl getDao() {
		return Dao;
	}
	public int raiseNewTicket(TicketBean ticketBean)
	{
		return getDao().raiseNewTicket(ticketBean);
		
	}
	
	public ArrayList<String> ListTicketCategory() {
		System.out.println("service entered");
		return getDao().ListTicketCategory();
	}
}
